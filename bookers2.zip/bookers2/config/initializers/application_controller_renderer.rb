# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '0127f114dcb46a4c8832cdbbb837c71d7a61317c0852f82a2cc4be89d6ed415fb2644a420b8be448602cf83b8eea2f3b2b97a2f76fda1d7e06dcc20756ccea82'